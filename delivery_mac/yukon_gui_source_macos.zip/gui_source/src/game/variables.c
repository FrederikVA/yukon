#include <stddef.h>
#include <time.h>
#include "structures.h"
#include "variables.h"

// Global piles (only capslog names for constants?)
Pile columns[7];
Pile foundations[4];

// Game phase
GamePhase currentPhase = STARTUP;

// Run control
int running = 1;

// Deck of cards
Card *deck = NULL;

// Timer state
int gameTimerActive = 0;
long gameElapsedBeforePause = 0;
long bestCompletionTime = 0;
time_t gameStartTime = 0;

// For printing
char lastCommand[100];
char message[200];

// Working file / deck
char currentFile[100] = "cards.txt";  // Default deck name

char cardToMove[3] = ""; // Card to move
char fromColumnOrField[3] = ""; // From column or field
char toColumnOrField[3] = ""; // To column or field
